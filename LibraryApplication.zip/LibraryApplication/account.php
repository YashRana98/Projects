


<?php

//Open in Notepad++
//CHANGE THE FILE EXTENSION TO .php

$hostname = "sql.njit.edu"     ; 	  // or "sql2.njit.edu"   OR "sql1.njit.edu"
$username = "ddp47" ;
$project  = "ddp47" ;
$password = "arterial8" ;

?>
