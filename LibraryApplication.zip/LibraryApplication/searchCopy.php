<?php
error_reporting (E_ERROR | E_WARNING | E_PARSE |E_NOTICE);
ini_set ('display_errors', 1);
include ("account.php");
$db = mysqli_connect ($hostname, $username, $password, $project);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL.";
  mysqli_connect_error();
  exit();
}
echo "<style>
	table, th, td 
	{
		border: 1px solid powderblue;
	}
	</style>";
$docID = $_GET['docID'];
$copyNo = $_GET['copyNo'];
$libID = $_GET['libID'];
$searchCopyB = "SELECT * FROM BORROWS WHERE DOCID = '$docID' AND LIBID = '$libID' AND COPYNO = '$copyNo'";
$searchCopyR = "SELECT * FROM RESERVES WHERE DOCID = '$docID' AND LIBID = '$libID' AND COPYNO = '$copyNo'";
($t = mysqli_query($db, $searchCopyB)) or die(mysqli_error($db));
($u = mysqli_query($db, $searchCopyR)) or die(mysqli_error($db));
$numB = mysqli_num_rows($t);
$numR = mysqli_num_rows($u);
if ($numB == 0 && $numR == 0) 
{
	$findPosition = "SELECT POSITION FROM COPY WHERE DOCID = '$docID' AND COPYNO = '$copyNo' AND LIBID = '$libID'";
	($v = mysqli_query($db, $findPosition)) or die(mysqli_error($db));
	while ($r = mysqli_fetch_array($v, MYSQLI_ASSOC))
	{
		$position = $r["POSITION"];
		echo "The copy is available and is at position: ${position}.";
	}
}
else if ($numB > 0)
{
	$findBorrower = "SELECT * FROM BORROWS, READER WHERE DOCID = '$docID' AND COPYNO = '$copyNo' AND LIBID = '$libID' AND BORROWS.READERID = READER.READERID";
	($w = mysqli_query($db, $findBorrower)) or die(mysqli_error($db));
	echo "
	<table>
	<th>Borrow ID</th>
	<th>Reader ID</th>
	<th>Borrowed</th>
	<th>Returned</th>
	<th>Reader Type</th>
	<th>Reader Name</th>
	<th>Reader Address</th>
		 ";
	while ($r = mysqli_fetch_array($w, MYSQLI_ASSOC))
	{
		$borNumber = $r["BORNUMBER"];
		$bReaderID = $r["READERID"];
		$bDocID = $r["DOCID"];
		$bCopyNo = $r["COPYNO"];
		$bLibID = $r["LIBID"];
		$bBDTime = $r["BDTIME"];
		$bRDTime = $r["RDTIME"];
		$readerName = $r["RNAME"];
		$readerType = $r["RTYPE"];
		$readerAddress = $r["ADDRESS"];
		
		echo "
			<tr>
			<td>$borNumber</td>
			<td>$bReaderID</td>
			<td>$bBDTime </td>
			<td>$bRDTime</td>
			<td>$readerType </td>
			<td>$readerName</td>
			<td>$readerAddress</td>
			</tr>
			 ";
	}
	echo "</table>";
}
else if ($numR > 0)
{
	$findReserver = "SELECT * FROM RESERVES, READER WHERE DOCID = '$docID' AND COPYNO = '$copyNo' AND LIBID = '$libID' AND RESERVES.READERID = READER.READERID";
	($w = mysqli_query($db, $findReserver)) or die(mysqli_error($db));
	echo "
	<table>
	<th>Reservation ID</th>
	<th>Reader ID</th>
	<th>Document ID</th>
	<th>Copy No.</th>
	<th>Library ID</th>
	<th>Reservation Date</th>
	<th>Reader Name</th>
	<th>Reader Type</th>
	<th>Reader Address</th>
		 ";
	while ($r = mysqli_fetch_array($w, MYSQLI_ASSOC))
	{
		$reserveNumber = $r["RESUMBER"];
		$rReaderID = $r["READERID"];
		$rDocID = $r["DOCID"];
		$rCopyNo = $r["COPYNO"];
		$rLibID = $r["LIBID"];
		$rDTime = $r["DTIME"];
		$readerName = $r["RNAME"];
		$readerType = $r["RTYPE"];
		$readerAddress = $r["ADDRESS"];
		
		echo "
			<tr>
			<td>$reserveNumber</td>
			<td>$rReaderID</td>
			<td>$rDocID</td>
			<td>$rCopyNo</td>
			<td>$rLibID</td>
			<td>$rDTime</td>
			<td>$readerName</td>
			<td>$readerType</td>
			<td>$readerAddress</td>
			</tr>
			 ";
	}
	echo "</table>";
}
?>