<?php
error_reporting (E_ERROR | E_WARNING | E_PARSE |E_NOTICE);
ini_set ('display_errors', 1);
include ("account.php");
$db = mysqli_connect ($hostname, $username, $password, $project);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL.";
  mysqli_connect_error();
  exit();
}
$readerID = $_GET['readerID'];
$readerType = $_GET['readerType'];
$readerAddress = $_GET['readerAddress'];
$readerName = $_GET['readerName'];
$readerPhone = $_GET['readerPhone'];
if (!isset($_GET['readerType']))
	$readerType = null;
if (!isset($_GET['readerName']))
	$readerName = null;
if (!isset($_GET['readerAddress']))
	$readerAddress = null;
if (!isset($_GET['readerPhone']))
	$readerPhone = null;
	
$insertReader = "INSERT INTO READER (READERID, RTYPE, RNAME, ADDRESS, PHONE) VALUES ('$readerID', '$readerType', '$readerName', '$readerAddress', '$readerPhone')";
($t = mysqli_query($db, $insertReader)) or die(mysqli_error($db));
echo "Successfully added reader.";
?>