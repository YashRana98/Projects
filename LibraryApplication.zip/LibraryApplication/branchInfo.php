<?php
error_reporting (E_ERROR | E_WARNING | E_PARSE |E_NOTICE);
ini_set ('display_errors', 1);
include ("account.php");
$db = mysqli_connect ($hostname, $username, $password, $project);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL.";
  mysqli_connect_error();
  exit();
}
$libID = $_GET['libraryID'];
$selectBranch = "SELECT LNAME, LLOCATION FROM BRANCH WHERE LIBID = '$libID'";
($t = mysqli_query($db, $selectBranch)) or die(mysqli_error($db));
while ($r = mysqli_fetch_array($t, MYSQLI_ASSOC))
{
	$branchName = $r['LNAME'];
	$branchLocation = $r['LLOCATION'];
}

echo "Branch Name: ${branchName}";
echo "<br>";
echo "Branch Location: ${branchLocation}";
?>