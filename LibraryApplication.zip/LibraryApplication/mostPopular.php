<?php
error_reporting (E_ERROR | E_WARNING | E_PARSE |E_NOTICE);
ini_set ('display_errors', 1);
include ("account.php");
$db = mysqli_connect ($hostname, $username, $password, $project);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL.";
  mysqli_connect_error();
  exit();
}
$selectPopular = "SELECT DOCUMENT.TITLE, COUNT(*)
					   FROM BORROWS, BOOK, DOCUMENT
					   WHERE BORROWS.DOCID = BOOK.DOCID AND BOOK.DOCID = DOCUMENT.DOCID AND BORROWS.BDTIME >= DATE_SUB(NOW(), INTERVAL 1 YEAR)
					   GROUP BY BOOK.ISBN
					   ORDER BY COUNT(*) DESC
					   LIMIT 10"
					   ;
($t = mysqli_query($db, $selectPopular)) or die(mysqli_error($db));
while ($r = mysqli_fetch_array($t, MYSQLI_ASSOC))
{
	$docTitle = $r['TITLE'];
	echo "${docTitle}";
	echo "<br><hr>";	
}
?>