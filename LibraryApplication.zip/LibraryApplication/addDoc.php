<?php
error_reporting (E_ERROR | E_WARNING | E_PARSE |E_NOTICE);
ini_set ('display_errors', 1);
include ("account.php");
$db = mysqli_connect ($hostname, $username, $password, $project);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL.";
  mysqli_connect_error();
  exit();
}
$docID = $_GET['docID'];
$title = $_GET['title'];
$pDate = $_GET['pDate'];
$pID = $_GET['pID'];
$insertDoc = "INSERT INTO DOCUMENT (DOCID, TITLE, PDATE, PUBLISHERID) VALUES ('$docID', '$title', '$pDate', '$pID')";
($t = mysqli_query($db, $insertDoc)) or die(mysqli_error($db));
echo "Successfully added document.";
?>