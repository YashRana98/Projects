<?php
error_reporting (E_ERROR | E_WARNING | E_PARSE |E_NOTICE);
ini_set ('display_errors', 1);
include ("account.php");
$db = mysqli_connect ($hostname, $username, $password, $project);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL.";
  mysqli_connect_error();
  exit();
}
$selectTopBorrowers = "SELECT RNAME, RTYPE, COUNT(*)
					   FROM READER, BORROWS
					   WHERE READER.READERID = BORROWS.READERID
					   GROUP BY READER.READERID
					   ORDER BY COUNT(*) DESC
					   LIMIT 10"
					   ;
($t = mysqli_query($db, $selectTopBorrowers)) or die(mysqli_error($db));
while ($r = mysqli_fetch_array($t, MYSQLI_ASSOC))
{
	$readerName = $r['RNAME'];
	$readerType = $r['RTYPE'];
	$numberBorrowed = $r['COUNT(*)'];
	echo "${readerName},${readerType}, ${numberBorrowed}";
	echo "<br><hr>";	
}
?>