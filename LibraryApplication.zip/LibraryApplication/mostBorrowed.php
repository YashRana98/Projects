<?php
error_reporting (E_ERROR | E_WARNING | E_PARSE |E_NOTICE);
ini_set ('display_errors', 1);
include ("account.php");
$db = mysqli_connect ($hostname, $username, $password, $project);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL.";
  mysqli_connect_error();
  exit();
}
$libID = $_GET['libID'];
$selectTopBorrowed = "SELECT DOCUMENT.TITLE, COUNT(*)
					   FROM BORROWS, BOOK, DOCUMENT
					   WHERE BORROWS.DOCID = BOOK.DOCID AND BOOK.DOCID = DOCUMENT.DOCID AND BORROWS.LIBID = '$libID'
					   GROUP BY BOOK.ISBN
					   ORDER BY COUNT(*) DESC
					   LIMIT 10"
					   ;
($t = mysqli_query($db, $selectTopBorrowed)) or die(mysqli_error($db));
while ($r = mysqli_fetch_array($t, MYSQLI_ASSOC))
{
	$docTitle = $r['TITLE'];
	echo "${docTitle}";
	echo "<br><hr>";	
}
?>