<?php
error_reporting (E_ERROR | E_WARNING | E_PARSE |E_NOTICE);
ini_set ('display_errors', 1);
include ("account.php");
$db = mysqli_connect ($hostname, $username, $password, $project);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL.";
  mysqli_connect_error();
  exit();
}
echo "<!DOCTYPE html>";

        echo "<head>";
		echo "<html lang='en'>";
		echo "<meta charset = 'UTF-8'>";
		echo "<title>Library Management System</title>";
		echo 
		"<style>
        
            #wbox
			{
				border: 3px solid #FF8C00; padding: 10px; border-radius: 5px;
				margin: auto; text-align: left; width: 65%; height: 60%;
				background-color: #FFF0F5;
			  
			}
            
            #A,#B,#C,#D,#E,#F,#G,#H,#I
			{
				width: 50%; height: 50%; display: none;
            	border-radius: 5px; text-align: left; border:1px dashed red;
				padding: 5px;
				
			}
			
        
        </style>";
        
      echo "</head>";
      echo "<body>";
      
          echo "<div id='wbox'>";          
             
                echo "<select name='choice' id='choice'>";
					echo "<option value = 'addDoc'>Add Document</option>";
					echo "<option value = 'addCopy'>Add Copy</option>";
                	echo "<option value = 'searchDocCopy'>Search Document Copy (Check Status)</option>";
                	echo "<option value = 'addReader'>Add Reader</option>";
                	echo "<option value = 'branchInfo'>Branch Information</option>";
                	echo "<option value = 'frequentBorrowers'>Top Frequent Borrowers</option>";
                	echo "<option value = 'mostBorrowedBooks'>Most Borrowed Books</option>";
                	echo "<option value = 'mostPopularBooks'>Most Popular Books</option>";
                	echo "<option value = 'avgFine'>Average Fine</option>";				
                echo "</select>";                    
			    echo " <b>Select</b><br><br>";
				         
              echo "<div id='A'>";
			    echo "<form action = 'addDoc.php' method = 'GET'>";
					echo "<br>";
					echo "<input type='text' name='docID' required>";                                    
					echo "<b>Enter Document ID</b><br>";       
					echo "<input type='text' name='title'>";                                    
					echo "<b>Enter Title</b><br>";		
					echo "<input type='text' name='pDate'>";                                    
					echo "<b>Enter Publication Date</b><br>";		
					echo "<input type='text' name='pID' required>";  				
					echo "<b>Enter Publisher ID</b><br>";
					echo "<br><hr>";
					echo "<input type = 'submit' name = 'Submit Request' value = 'Submit'>";
				echo "</form>";
              echo "</div>";              
			  
			  echo "<div id='I'>";
			    echo "<form action = 'addCopy.php' method = 'GET'>";
					echo "<br>";
					echo "<input type='text' name='docID'>";                                    
					echo "<b>Enter Document ID</b><br>";       
					echo "<input type='text' name='copyNo'>";                                    
					echo "<b>Enter Copy Number</b><br>";		
					echo "<input type='text' name='libID'>";                                    
					echo "<b>Enter Library ID</b><br>";		
					echo "<input type='text' name='position'>";  				
					echo "<b>Enter Position</b><br>";
					echo "<br><hr>";
					echo "<input type = 'submit' name = 'Submit Request' value = 'Submit'>";
				echo "</form>";
              echo "</div>";
          
              echo "<div id='B'>";
				echo "<form action = 'searchCopy.php' method = 'GET'>";
					echo "<br>";
					echo "<input type='text' name='docID'>";                                    
					echo "<b>Enter Document ID</b><br>";       
					echo "<input type='text' name='copyNo'>";                                    
					echo "<b>Enter Copy Number</b><br>";		
					echo "<input type='text' name='libID'>";                                    
					echo "<b>Enter Library ID</b><br>";		
					echo "<br><hr>";
					echo "<input type = 'submit' name = 'Submit Request' value = 'Submit'>";	
				echo "</form>";				
              echo "</div>";
			  
              echo "<div id='C'>";
				echo "<form action = 'addReader.php' method = 'GET'>";
					echo "<br>";
					echo "<input type='text' name='readerID' required>";                                    
					echo "<b>Enter Unique Reader ID</b><br>";
				    echo "<select name='readerType'>";
					echo "<option value='STUDENT'>Student</option>";
					echo "<option value='SENIOR CITIZEN'>Senior Citizen</option>";
					echo "<option value='STAFF'>Staff</option>";
				    echo "</select>";
					echo "<b>Select Reader Type</b><br>";
					echo "<input type='text' name='readerName'>";                                    
					echo "<b>Enter Reader's Name</b><br>";
					echo "<input type='text' name='readerAddress'>";                                    
					echo "<b>Enter Reader's Address</b><br>";
					echo "<input type='text' name='readerPhone'>";                                    
					echo "<b>Enter Reader's Phone No.</b><br>";					
					echo "<br><hr>";
					echo "<input type = 'submit' name = 'Submit Request' value = 'Submit'>";
				echo "</form>";	
              echo "</div>";	

              echo "<div id='D'>";
				echo "<form action = 'branchInfo.php' method = 'GET'>";
                echo "<br>";
				$selectBranches = "SELECT LIBID FROM BRANCH";
				($t = mysqli_query($db, $selectBranches)) or die(mysqli_error($db));
				echo "<select name='libraryID'>";
				while ($r = mysqli_fetch_array($t, MYSQLI_ASSOC))
				{
					$libID = $r["LIBID"];
					echo "<option value='$libID'>$libID</option>";
				}
				echo "</select>";
				echo "Select Library ID";
				echo "<br><hr>";
				echo "<input type = 'submit' name = 'Submit Request' value = 'Submit'>";
				echo "</form>";	
              echo "</div>";	
			  
              echo "<div id='E'>";
			  	echo "<form action = 'frequentBorrowers.php' method = 'GET'>";
					echo "<input type = 'submit' name = 'Submit Request' value = 'Submit'>";
				echo "</form>";	
              echo "</div>";

              echo "<div id='F'>";
			  	echo "<form action = 'mostBorrowed.php' method = 'GET'>";
                echo "<br>";
				$selectBranches = "SELECT LIBID FROM BRANCH";
				($t = mysqli_query($db, $selectBranches)) or die(mysqli_error($db));
				echo "<select name='libID'>";
				while ($r = mysqli_fetch_array($t, MYSQLI_ASSOC))
				{
					$libID = $r["LIBID"];
					echo "<option value='$libID'>$libID</option>";
				}
				echo "</select>";
				echo "Select Library ID";
				echo "<br><hr>";
				echo "<input type = 'submit' name = 'Submit Request' value = 'Submit'>";
				echo "</form>";	
              echo "</div>";		
			  
              echo "<div id='G'>";
				echo "<form action = 'mostPopular.php' method = 'GET'>";
					echo "<br>";                                   
					echo "<input type = 'submit' name = 'Submit Request' value = 'Submit'>";
				echo "</form>";
              echo "</div>";              
			  
              echo "<div id='H'>";
			  	echo "<form action = 'avgFine.php' method = 'GET'>";
					echo "<br>";
					echo "<input type = 'submit' name = 'Submit Request' value = 'Submit'>";
				echo "</form>";
              echo "</div>";


              echo "<br>";
			  echo "<a href='main.php'>Logout</a>";
			  
		    echo "</div>";
          
      echo "</body>";

echo "</html>";


echo "<script>
'use strict';
var somechoice = document.getElementById('choice')
somechoice.addEventListener('change', F);
var ptrA = document.getElementById('A');
var ptrB = document.getElementById('B');
var ptrC = document.getElementById('C');
var ptrD = document.getElementById('D');
var ptrE = document.getElementById('E');
var ptrF = document.getElementById('F');
var ptrG = document.getElementById('G');
var ptrH = document.getElementById('H');
var ptrI = document.getElementById('I');

function F( )
{
	if (somechoice.value == 'addDoc') 			
	{
		ptrA.style.display='block';
		ptrB.style.display='none';
		ptrC.style.display='none';
		ptrD.style.display='none';
		ptrE.style.display='none';
		ptrF.style.display='none';
		ptrG.style.display='none';
		ptrH.style.display='none';		
		ptrI.style.display='none';		
	}
	else if(somechoice.value == 'searchDocCopy')
	{
		ptrA.style.display='none';
		ptrB.style.display='block';
		ptrC.style.display='none';
		ptrD.style.display='none';
		ptrE.style.display='none';
		ptrF.style.display='none';
		ptrG.style.display='none';
		ptrH.style.display='none';
		ptrI.style.display='none';		
	}	
	else if(somechoice.value == 'addReader')
	{
		ptrA.style.display='none';
		ptrB.style.display='none';
		ptrC.style.display='block';
		ptrD.style.display='none';
		ptrE.style.display='none';
		ptrF.style.display='none';
		ptrG.style.display='none';
		ptrH.style.display='none';	
		ptrI.style.display='none';
	}	
	else if(somechoice.value == 'branchInfo')
	{
		ptrA.style.display='none';
		ptrB.style.display='none';
		ptrC.style.display='none';
		ptrD.style.display='block';
		ptrE.style.display='none';
		ptrF.style.display='none';
		ptrG.style.display='none';
		ptrH.style.display='none';	
		ptrI.style.display='none';
	}	
	else if(somechoice.value == 'frequentBorrowers')
	{
		ptrA.style.display='none';
		ptrB.style.display='none';
		ptrC.style.display='none';
		ptrD.style.display='none';
		ptrE.style.display='block';
		ptrF.style.display='none';
		ptrG.style.display='none';
		ptrH.style.display='none';	
		ptrI.style.display='none';
	}	
	else if(somechoice.value == 'mostBorrowedBooks')
	{
		ptrA.style.display='none';
		ptrB.style.display='none';
		ptrC.style.display='none';
		ptrD.style.display='none';
		ptrE.style.display='none';
		ptrF.style.display='block';
		ptrG.style.display='none';
		ptrH.style.display='none';	
		ptrI.style.display='none';
	}
	else if(somechoice.value == 'mostPopularBooks')
	{
		ptrA.style.display='none';
		ptrB.style.display='none';
		ptrC.style.display='none';
		ptrD.style.display='none';
		ptrE.style.display='none';
		ptrF.style.display='none';
		ptrG.style.display='block';
		ptrH.style.display='none';	
		ptrI.style.display='none';
	}	
	else if(somechoice.value == 'addCopy')
	{
		ptrA.style.display='none';
		ptrB.style.display='none';
		ptrC.style.display='none';
		ptrD.style.display='none';
		ptrE.style.display='none';
		ptrF.style.display='none';
		ptrG.style.display='none';
		ptrH.style.display='none';	
		ptrI.style.display='block';
	}
	else
	{
		ptrB.style.display='none'
		ptrA.style.display='none'
		ptrC.style.display='none';
		ptrD.style.display='none';
		ptrE.style.display='none';
		ptrF.style.display='none';
		ptrG.style.display='none';
		ptrH.style.display='block';	
	}
}
</script>";
?>