<?php
error_reporting (E_ERROR | E_WARNING | E_PARSE |E_NOTICE);
ini_set ('display_errors', 1);
include ("account.php");
$db = mysqli_connect ($hostname, $username, $password, $project);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL.";
  mysqli_connect_error();
  exit();
}
$readerID = $_GET['readerID'];
$validReader = "SELECT *
			   FROM READER
			   WHERE READERID = '$readerID'";
($t = mysqli_query($db, $validReader))  or  die (mysqli_error($db));
if (mysqli_num_rows($t) == 0)
{
	echo "Invalid Card Number. Retry.";
	header("refresh:3; url = readerLogin.php");
	exit();
}
		   
echo "<!DOCTYPE html>";

        echo "<head>";
		echo "<html lang='en'>";
		echo "<meta charset = 'UTF-8'>";
		echo "<title>Library Management System</title>";
		echo 
		"<style>
        
            #wbox
			{
				border: 3px solid #FF8C00; padding: 10px; border-radius: 5px;
				margin: auto; text-align: left; width: 65%; height: 60%;
				background-color: #FFF0F5;
			  
			}
            
            #A,#B,#C,#D,#E,#F,#G,#H,#I
			{
				width: 70%; height: 50%; display: none;
            	border-radius: 5px; text-align: left; border:1px dashed red;
				padding: 5px;
				
			}
			
        
        </style>";
        
      echo "</head>";
      echo "<body>";
      
          echo "<div id='wbox'>";          
             
                echo "<select name='choice' id='choice'>";
					echo "<option value = 'searchDoc'>Search Document</option>";
					echo "<option value = 'checkoutCopy'>Checkout</option>";
                	echo "<option value = 'reserveCopy'>Reserve</option>";
                	echo "<option value = 'return'>Return</option>";
                	echo "<option value = 'computeFine'>Compute Fine</option>";
                	echo "<option value = 'reservedDocs'>Reserved Documents</option>";
                	echo "<option value = 'searchByPublisher'>Search Documents by Publisher</option>";
               			
                echo "</select>";                    
			    echo " <b>Select</b><br><br>";
				         
              echo "<div id='A'>";
			    echo "<form action = 'readerFunctions/searchDoc.php' method = 'GET'>";
					echo "<br>";
					echo "<input type='text' name='docID'>";
					echo "<input type='radio' name='searchBy' value='byDocID'>Document ID<br>";
					echo "<input type='text' name='docTitle'>";
					echo "<input type='radio' name='searchBy' value='byDocTitle'>Title<br>";
					echo "<input type='text' name='docPublisher'>";
					echo "<input type='radio' name='searchBy' value='byDocPublisher'>Publisher Name";
					echo "<input type='hidden' name='readerID' value='${readerID}'>";
					echo "<br><hr>";
					echo "<input type = 'submit' name = 'Submit Request' value = 'Submit'>";
				echo "</form>";
              echo "</div>";              
			  
			  echo "<div id='I'>";
			    echo "<form action = 'readerFunctions/docCheckout.php' method = 'GET'>";
					echo "<br>";
					echo "<input type='text' name='docID' required>";                                    
					echo "<b>Enter Document ID</b><br>";       
					echo "<input type='text' name='copyNo' required>";                                    
					echo "<b>Enter Copy Number</b><br>";		
					$selectBranches = "SELECT LIBID FROM BRANCH";
					($t = mysqli_query($db, $selectBranches)) or die(mysqli_error($db));
					echo "<select name='libID'>";
					while ($r = mysqli_fetch_array($t, MYSQLI_ASSOC))
					{	
						$libID = $r["LIBID"];
						echo "<option value='$libID'>$libID</option>";
					}
					echo "</select>";					
					echo "<b>Enter Library ID</b><br>";	
					echo "<input type='hidden' name='readerID' value='${readerID}'>";					
					echo "<br><hr>";
					echo "<input type = 'submit' name = 'Submit Request' value = 'Submit'>";
				echo "</form>";
              echo "</div>";
          
              echo "<div id='B'>";
			    echo "<form action = 'readerFunctions/docReserve.php' method = 'GET'>";
					echo "<br>";
					echo "<input type='text' name='docID' required>";                                    
					echo "<b>Enter Document ID</b><br>";       
					echo "<input type='text' name='copyNo' required>";                                    
					echo "<b>Enter Copy Number</b><br>";		
					$selectBranches = "SELECT LIBID FROM BRANCH";
					($t = mysqli_query($db, $selectBranches)) or die(mysqli_error($db));
					echo "<select name='libID'>";
					while ($r = mysqli_fetch_array($t, MYSQLI_ASSOC))
					{	
						$libID = $r["LIBID"];
						echo "<option value='$libID'>$libID</option>";
					}
					echo "</select>";					
					echo "<b>Enter Library ID</b><br>";	
					echo "<input type='hidden' name='readerID' value='${readerID}'>";					
					echo "<br><hr>";
					echo "<input type = 'submit' name = 'Submit Request' value = 'Submit'>";
					echo "</form>";
				echo "</div>";
			  
              echo "<div id='C'>";
				echo "<form action = 'readerFunctions/returnDocInfo.php' method = 'GET'>";
					echo "<br>";
					$selectBranches = "SELECT LIBID FROM BRANCH";
					($t = mysqli_query($db, $selectBranches)) or die(mysqli_error($db));
					echo "<select name='libID'>";
					while ($r = mysqli_fetch_array($t, MYSQLI_ASSOC))
					{	
						$libID = $r["LIBID"];
						echo "<option value='$libID'>$libID</option>";
					}
					echo "</select>";					
					echo "<b>Enter Library ID</b><br>";	
					echo "<input type='hidden' name='readerID' value='${readerID}'>";	
          echo "<br><hr>";
					echo "<input type = 'submit' name = 'Submit Request' value = 'Submit'>";					
				echo "</form>";	
              echo "</div>";	

              echo "<div id='D'>";
				echo "<form action = 'readerFunctions/computeFine.php' method = 'GET'>";
					echo "<br>";
					$selectDocs = "SELECT * FROM BORROWS, DOCUMENT WHERE BORROWS.READERID = '$readerID' AND BORROWS.DOCID = DOCUMENT.DOCID AND BORROWS.RDTIME IS NULL";
					($t = mysqli_query($db, $selectDocs)) or die(mysqli_error($db));
					echo "<select name='returnDoc'>";
					while ($r = mysqli_fetch_array($t, MYSQLI_ASSOC))
					{	
						$docTitle = $r['TITLE'];
						$bNumber = $r['BORNUMBER'];
						echo "<option value='$bNumber'>${docTitle} || ${bNumber}</option>";
					}
					echo "</select>";					
					echo "<input type='hidden' name='readerID' value='${readerID}'>";					
					echo "<br><hr>";
					echo "<input type = 'submit' name = 'Submit Request' value = 'Submit'>";
				echo "</form>";	
              echo "</div>";	
			  
              echo "<div id='E'>";
			  	echo "<form action = 'readerFunctions/reservedDocs.php' method = 'GET'>";
					echo "<input type='hidden' name='readerID' value='${readerID}'>";					
					echo "<input type = 'submit' name = 'Submit Request' value = 'Submit'>";
				echo "</form>";	
              echo "</div>";

              echo "<div id='F'>";
			  	echo "<form action = 'readerFunctions/publisherDocs.php' method = 'GET'>";
                echo "<br>";
				$selectPublishers = "SELECT PUBNAME FROM PUBLISHER";
				($t = mysqli_query($db, $selectPublishers)) or die(mysqli_error($db));
				echo "<select name='pName'>";
				while ($r = mysqli_fetch_array($t, MYSQLI_ASSOC))
				{
					$pName = $r["PUBNAME"];
					echo "<option value='$pName'>$pName</option>";
				}
				echo "</select>";
				echo "Select Publisher Name";
				echo "<input type='hidden' name='readerID' value='${readerID}'>";				
				echo "<br><hr>";
				echo "<input type = 'submit' name = 'Submit Request' value = 'Submit'>";
				echo "</form>";	
              echo "</div>";		
			  
              echo "<div id='G'>";
				echo "<form action = 'mostPopular.php' method = 'GET'>";
					echo "<br>";                                   
					echo "<input type = 'submit' name = 'Submit Request' value = 'Submit'>";
				echo "</form>";
              echo "</div>";              
			  
              echo "<div id='H'>";
			  	echo "<form action = 'avgFine.php' method = 'GET'>";
					echo "<br>";
					echo "<input type = 'submit' name = 'Submit Request' value = 'Submit'>";
				echo "</form>";
              echo "</div>";


              echo "<br>";
			  echo "<a href='main.php'>Logout</a>";
			  
		    echo "</div>";
			
      echo "</body>";

echo "</html>";


echo "<script>
'use strict';
var somechoice = document.getElementById('choice')
somechoice.addEventListener('change', F);
var ptrA = document.getElementById('A');
var ptrB = document.getElementById('B');
var ptrC = document.getElementById('C');
var ptrD = document.getElementById('D');
var ptrE = document.getElementById('E');
var ptrF = document.getElementById('F');
var ptrG = document.getElementById('G');
var ptrH = document.getElementById('H');
var ptrI = document.getElementById('I');

function F( )
{
	if (somechoice.value == 'searchDoc') 			
	{
		ptrA.style.display='block';
		ptrB.style.display='none';
		ptrC.style.display='none';
		ptrD.style.display='none';
		ptrE.style.display='none';
		ptrF.style.display='none';
		ptrG.style.display='none';
		ptrH.style.display='none';		
		ptrI.style.display='none';		
	}
	else if(somechoice.value == 'reserveCopy')
	{
		ptrA.style.display='none';
		ptrB.style.display='block';
		ptrC.style.display='none';
		ptrD.style.display='none';
		ptrE.style.display='none';
		ptrF.style.display='none';
		ptrG.style.display='none';
		ptrH.style.display='none';
		ptrI.style.display='none';		
	}	
	else if(somechoice.value == 'return')
	{
		ptrA.style.display='none';
		ptrB.style.display='none';
		ptrC.style.display='block';
		ptrD.style.display='none';
		ptrE.style.display='none';
		ptrF.style.display='none';
		ptrG.style.display='none';
		ptrH.style.display='none';	
		ptrI.style.display='none';
	}	
	else if(somechoice.value == 'computeFine')
	{
		ptrA.style.display='none';
		ptrB.style.display='none';
		ptrC.style.display='none';
		ptrD.style.display='block';
		ptrE.style.display='none';
		ptrF.style.display='none';
		ptrG.style.display='none';
		ptrH.style.display='none';	
		ptrI.style.display='none';
	}	
	else if(somechoice.value == 'reservedDocs')
	{
		ptrA.style.display='none';
		ptrB.style.display='none';
		ptrC.style.display='none';
		ptrD.style.display='none';
		ptrE.style.display='block';
		ptrF.style.display='none';
		ptrG.style.display='none';
		ptrH.style.display='none';	
		ptrI.style.display='none';
	}	
	else if(somechoice.value == 'searchByPublisher')
	{
		ptrA.style.display='none';
		ptrB.style.display='none';
		ptrC.style.display='none';
		ptrD.style.display='none';
		ptrE.style.display='none';
		ptrF.style.display='block';
		ptrG.style.display='none';
		ptrH.style.display='none';	
		ptrI.style.display='none';
	}
	else if(somechoice.value == 'mostPopularBooks')
	{
		ptrA.style.display='none';
		ptrB.style.display='none';
		ptrC.style.display='none';
		ptrD.style.display='none';
		ptrE.style.display='none';
		ptrF.style.display='none';
		ptrG.style.display='block';
		ptrH.style.display='none';	
		ptrI.style.display='none';
	}	
	else if(somechoice.value == 'checkoutCopy')
	{
		ptrA.style.display='none';
		ptrB.style.display='none';
		ptrC.style.display='none';
		ptrD.style.display='none';
		ptrE.style.display='none';
		ptrF.style.display='none';
		ptrG.style.display='none';
		ptrH.style.display='none';	
		ptrI.style.display='block';
	}
	else
	{
		ptrB.style.display='none'
		ptrA.style.display='none'
		ptrC.style.display='none';
		ptrD.style.display='none';
		ptrE.style.display='none';
		ptrF.style.display='none';
		ptrG.style.display='none';
		ptrH.style.display='block';	
	}
}
</script>";
?>