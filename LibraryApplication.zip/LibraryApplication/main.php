<?php
error_reporting (E_ERROR | E_WARNING | E_PARSE |E_NOTICE);
ini_set ('display_errors', 1);
include ("account.php");
$db = mysqli_connect ($hostname, $username, $password, $project);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL.";
  mysqli_connect_error();
  exit();
}
echo "<!DOCTYPE html>";

        echo "<head>";
		echo "<html lang='en'>";
		echo "<meta charset = 'UTF-8'>";
		echo "<title>Library Management System</title>";
		echo 
		"<style>
        
            #wbox
			{
				border: 3px solid #FF8C00; padding: 10px; border-radius: 5px;
				margin: auto; text-align: left; width: 65%; height: 60%;
				background-color: #FFF0F5;
			  
			}
            
            #A,#B 
			{
				width: 50%; height: 50%; display: none;
            	border-radius: 5px; text-align: left; border:1px dashed red;
				padding: 5px;
				
			}
			
        
        </style>";
        
      echo "</head>";
      echo "<body>";
      
          echo "<div id='wbox'>";
        
             
                echo "<select name='choice' id='choice' onchange='location = this.value;'>";
                	echo "<option value = 'default'>Choose</option>";
                	echo "<option value = '/~ddp47/LibraryApplication/readerLogin.php'>Reader</option>";
                	echo "<option value = '/~ddp47/LibraryApplication/adminLogin.php'>Admin</option>";
                echo "</select>";                    
			    echo " <b>Select</b><br><br>";
				         
              echo "<div id='A'>";
                echo "<br>";
                echo "<input type='text' name='cardnumber'>";                                    
				echo "<b>Enter Card Number</b><br>";
				echo "<br><hr>";
				echo "<input type = 'submit' name = 'Submit Request' value = 'Submit'>";
              echo "</div>";
          
              echo "<div id='B'>";
                echo "<br>";
                echo "<input type = 'text' name = 'adminID'>";
				echo "<b>Enter ID</b><br>";
                echo "<input type = 'password' name = 'adminpassword'>";
				echo "<br><hr>";
				echo "<input type = 'submit' name = 'Submit Request' value = 'Submit'>";				
				echo "<b>Enter Password</b><br>";
              echo "</div>";
			  
              
			  


              echo "<br>";
			  echo "<a href='main.php'>Quit</a>";

		    echo "</div>";
          
      echo "</body>";

echo "</html>";


echo "<script>
'use strict';
var somechoice = document.getElementById('choice')
somechoice.addEventListener('change', F);
var ptrA = document.getElementById('A')
var ptrB= document.getElementById('B')

function F( )
{
	if (somechoice.value == 'reader') 			
	{
		ptrA.style.display='block'
		ptrB.style.display='none'
	}
	else if(somechoice.value == 'admin')
	{
		ptrB.style.display='block'
		ptrA.style.display='none'
	}
	else
	{
	ptrB.style.display='none'
	ptrA.style.display='none'
	}
}
</script>";
?>