<?php
error_reporting (E_ERROR | E_WARNING | E_PARSE |E_NOTICE);
ini_set ('display_errors', 1);
include ("account.php");
$db = mysqli_connect ($hostname, $username, $password, $project);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL.";
  mysqli_connect_error();
  exit();
}
$docID = $_GET['docID'];
$copyNo = $_GET['copyNo'];
$libID = $_GET['libID'];
$position = $_GET['position'];
$insertDoc = "INSERT INTO COPY (DOCID, COPYNO, LIBID, POSITION) VALUES ('$docID', '$copyNo', '$libID', '$position')";
($t = mysqli_query($db, $insertDoc)) or die(mysqli_error($db));
echo "Successfully added copy.";
?>