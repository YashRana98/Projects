<?php
error_reporting (E_ERROR | E_WARNING | E_PARSE |E_NOTICE);
ini_set ('display_errors', 1);
include ("account.php");
$db = mysqli_connect ($hostname, $username, $password, $project);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL.";
  mysqli_connect_error();
  exit();
}
$query = "SELECT B.READERID, B.RNAME, B.totalFine/A.NUM AS avgFine
		  FROM
		  ((SELECT COUNT(*) AS NUM, BORROWS.READERID
		  FROM BORROWS
		  GROUP BY BORROWS.READERID) AS A,
		  (SELECT READER.READERID, READER.RNAME, LATE_FINE(BORROWS.BDTIME, BORROWS.RDTIME) AS totalFine
		   FROM READER, BORROWS
		   WHERE READER.READERID = BORROWS.READERID
		   GROUP BY READER.READERID) AS B)
           WHERE A.READERID = B.READERID
		   ORDER BY avgFine DESC
		   ";
		  
($t = mysqli_query($db, $query)) or die(mysqli_error($db));
while ($r = mysqli_fetch_array($t, MYSQLI_ASSOC))
{
	$readerName = $r['RNAME'];
	$fine = round($r['avgFine'],2);
echo "${readerName}, $${fine}";
echo "<br>";
}
?>

