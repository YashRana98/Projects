<?php
error_reporting (E_ERROR | E_WARNING | E_PARSE |E_NOTICE);
ini_set ('display_errors', 1);
include ("account.php");
$db = mysqli_connect ($hostname, $username, $password, $project);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL.";
  mysqli_connect_error();
  exit();
}
echo "<!DOCTYPE html>";

        echo "<head>";
		echo "<html lang='en'>";
		echo "<meta charset = 'UTF-8'>";
		echo "<title>Library Management System</title>";
		echo 
		"<style>
        
            #wbox
			{
				border: 3px solid #FF8C00; padding: 10px; border-radius: 5px;
				margin: auto; text-align: left; width: 65%; height: 60%;
				background-color: #FFF0F5;
			  
			}		
        </style>";
        
      echo "</head>";
      echo "<body>";
      
          echo "<div id='wbox'>";
     				         
              echo "<div id='A'>";
				echo "<form action='readerportal.php'>";
					echo "<br>";
					echo "<input type='text' name='readerID'>";                                    
					echo "<b>Enter Card Number</b><br>";
					echo "<br><hr>";
					echo "<input type = 'submit' name = 'Submit Request' value = 'Submit'>";
				echo "</form>";
              echo "</div>";
        	 
              echo "<br>";
          
		    echo "</div>";
          
      echo "</body>";

echo "</html>";
?>