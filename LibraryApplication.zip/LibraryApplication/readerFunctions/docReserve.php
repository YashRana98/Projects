<?php
error_reporting (E_ERROR | E_WARNING | E_PARSE |E_NOTICE);
ini_set ('display_errors', 1);
include ("../account.php");
$db = mysqli_connect ($hostname, $username, $password, $project);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL.";
  mysqli_connect_error();
  exit();
}
$readerID = $_GET['readerID'];
$docID = $_GET['docID'];
$copyNo = $_GET['copyNo'];
$libID = $_GET['libID'];

$copyExists = "SELECT *
			  FROM COPY
			  WHERE DOCID = '$docID' AND COPYNO = '$copyNo' AND LIBID = '$libID'";
($t = mysqli_query($db, $copyExists))  or  die (mysqli_error($db));
if (mysqli_num_rows($t) == 0)
{
	echo "Invalid Document/Copy.";
	exit();
}
$uniqueID = uniqid();
$insertQuery = "INSERT INTO RESERVES(RESUMBER, READERID, DOCID, COPYNO, LIBID, DTIME) VALUES 
			    ('${uniqueID}', '${readerID}', '${docID}', '${copyNo}', '${libID}', NOW())";
($t = mysqli_query($db, $insertQuery))  or  die (mysqli_error($db));
echo "Successfully reserved.";
?>