<?php
error_reporting (E_ERROR | E_WARNING | E_PARSE |E_NOTICE);
ini_set ('display_errors', 1);
include ("../account.php");
$db = mysqli_connect ($hostname, $username, $password, $project);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL.";
  mysqli_connect_error();
  exit();
}
$readerID = $_GET['readerID'];
$pName = $_GET['pName'];
$docsByPublisher = "SELECT * 
		  FROM PUBLISHER, DOCUMENT
		  WHERE PUBNAME = '$pName' 
		  AND
		  PUBLISHER.PUBLISHERID = DOCUMENT.PUBLISHERID";
($t = mysqli_query($db, $docsByPublisher)) or die(mysqli_error($db));
echo "Document ID, Document Title, Publication Date, Publisher ID, Publisher Address";
echo "<br><hr>";
while ($r = mysqli_fetch_array($t, MYSQLI_ASSOC))
{
	$docID = $r['DOCID'];
	$title = $r['TITLE'];
	$pDate = $r['PDATE'];
	$pID = $r['PUBLISHERID'];
	$pAddress = $r['ADDRESS'];
	echo "${docID}, ${title}, ${pDate}, ${pID}, ${pAddress}";
	echo "<br>";	
}

?>