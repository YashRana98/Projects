<?php
error_reporting (E_ERROR | E_WARNING | E_PARSE |E_NOTICE);
ini_set ('display_errors', 1);
include ("../account.php");
$db = mysqli_connect ($hostname, $username, $password, $project);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL.";
  mysqli_connect_error();
  exit();
}
if ((($_GET['docID'] == '') && ($_GET['docTitle'] == '') && ($_GET['docPublisher'] == '')) ||(!isset($_GET['searchBy'])))
{
	echo "Please select an appropriate search option and provide a valid input.";
	exit();
}
if (isset($_GET['docID']) && $_GET['searchBy'] == 'byDocID' && !($_GET['docID'] == ''))
{
	$query = "SELECT *
			  FROM DOCUMENT
			  WHERE DOCID = '${_GET['docID']}'";
}
else if (isset($_GET['docTitle']) && $_GET['searchBy'] == 'byDocTitle' && !($_GET['docTitle'] == ''))
{
	$query = "SELECT *
			  FROM DOCUMENT
			  WHERE TITLE = '${_GET['docTitle']}'";
}
else if (isset($_GET['docPublisher']) && $_GET['searchBy'] == 'byDocPublisher' && !($_GET['docPublisher'] == ''))
{
	$query = "SELECT *
		      FROM DOCUMENT, PUBLISHER
		      WHERE DOCUMENT.PUBLISHERID = PUBLISHER.PUBLISHERID AND PUBLISHER.PUBNAME = '${_GET['docPublisher']}'";
}
else
{
	echo "Please select an appropriate search option and provide a valid input."; 
	exit();
}
if (isset($query))
{
	($t = mysqli_query($db, $query)) or die(mysqli_error($db));
	echo "Document ID, Title, Publication Date, Publisher ID";
	echo "<br><hr>";
	while ($r = mysqli_fetch_array($t, MYSQLI_ASSOC))
	{
		$documentID = $r['DOCID'];
		$documentTitle = $r['TITLE'];
		$publicationDate = $r['PDATE'];
		$publisherID = $r['PUBLISHERID'];
		echo "${documentID}, ${documentTitle}, ${publicationDate}, ${publisherID}";
		echo "<br>";
	}
}
?>