<?php
error_reporting (E_ERROR | E_WARNING | E_PARSE |E_NOTICE);
ini_set ('display_errors', 1);
include ("../account.php");
$db = mysqli_connect ($hostname, $username, $password, $project);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL.";
  mysqli_connect_error();
  exit();
}
$readerID = $_GET['readerID'];
$returnDoc = $_GET['returnDoc'];

$computeFine = "SELECT LATE_FINE(BORROWS.BDTIME, BORROWS.RDTIME) AS FINE
				FROM BORROWS WHERE BORNUMBER = '$returnDoc'";
($u = mysqli_query($db, $computeFine))  or  die (mysqli_error($db));
$fine = 0.00;
while ($v = mysqli_fetch_array($u, MYSQLI_ASSOC))
{
	$fine = $v['FINE'];
}
echo "You owe $${fine}.";
?>