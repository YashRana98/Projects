<?php
error_reporting (E_ERROR | E_WARNING | E_PARSE |E_NOTICE);
ini_set ('display_errors', 1);
include ("../account.php");
$db = mysqli_connect ($hostname, $username, $password, $project);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL.";
  mysqli_connect_error();
  exit();
}
$readerID = $_GET['readerID'];

$query = "
	SELECT RESERVES.LIBID, RESERVES.DOCID, RESERVES.COPYNO, BORROWS.RDTIME
	FROM RESERVES LEFT OUTER JOIN BORROWS ON 
	RESERVES.DOCID = BORROWS.DOCID
	AND 
	RESERVES.COPYNO = BORROWS.COPYNO
	AND 
	RESERVES.LIBID = BORROWS.LIBID
	WHERE
	RESERVES.READERID = '$readerID'
	AND
	(BORROWS.RDTIME = (SELECT MAX(RDTIME) 
					  FROM BORROWS 
					  WHERE 
					  BORROWS.DOCID = RESERVES.DOCID
					  AND 
					  BORROWS.COPYNO = RESERVES.COPYNO 
					  AND 
					  BORROWS.LIBID = RESERVES.LIBID)
	OR 
	BORROWS.RDTIME IS NULL)
	GROUP BY RESERVES.DOCID, RESERVES.COPYNO
";				  
				 																		  
($t = mysqli_query($db, $query)) or die(mysqli_error($db));
echo "Library ID, Document ID, Copy Number, Availability";
echo "<br><hr>";
while ($r = mysqli_fetch_array($t, MYSQLI_ASSOC))
{
	$libID = $r['LIBID'];
	$docID = $r['DOCID'];
	$copyNo = $r['COPYNO'];
	$returnDate = $r['RDTIME'];
	$neverBorrowed = "SELECT * FROM BORROWS WHERE DOCID = '$docID' AND COPYNO = '$copyNo' AND LIBID = '$libID'";
	($u = mysqli_query($db, $neverBorrowed)) or die(mysqli_error($db));
	$num = mysqli_num_rows($u);
	if (($returnDate == '' || $returnDate = NULL) && $num > 0)
		$returnDate = 'Borrowed';
	else if ($num == 0)
		$returnDate = 'Be the first to borrow';
	else 
		$returnDate = 'Available';
	echo "${libID}, ${docID}, ${copyNo}, ${returnDate}";
	echo "<br>";
}


?>