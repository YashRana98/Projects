<?php
error_reporting (E_ERROR | E_WARNING | E_PARSE |E_NOTICE);
ini_set ('display_errors', 1);
include ("../account.php");
$db = mysqli_connect ($hostname, $username, $password, $project);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL.";
  mysqli_connect_error();
  exit();
}
$readerID = $_GET['readerID'];
$libID = $_GET['libID'];
echo "
					<form action = 'returnDoc.php' method = 'GET'>";
					$selectDocs = "SELECT * 
								   FROM BORROWS, DOCUMENT 
								   WHERE
								   BORROWS.READERID = '$readerID' 
								   AND 
								   BORROWS.DOCID = DOCUMENT.DOCID 
								   AND
								   BORROWS.LIBID = '$libID'
								   AND
								   BORROWS.RDTIME IS NULL";
					($t = mysqli_query($db, $selectDocs)) or die(mysqli_error($db));
					echo "<select name='returnDoc'>";
					while ($r = mysqli_fetch_array($t, MYSQLI_ASSOC))
					{	
						$docTitle = $r['TITLE'];
						$bNumber = $r['BORNUMBER'];
						echo "<option value='$bNumber'>${docTitle} || ${bNumber}</option>";
					}
					echo "</select>";					
					echo "<input type='hidden' name='readerID' value='${readerID}'>";	
					echo "<input type='hidden' name='libID' value='${libID}'>";					
					echo "<br><br>";
					echo "<input type = 'submit' name = 'Submit Request' value = 'Submit'>";
					echo "</form>
		";
?>