<?php
error_reporting (E_ERROR | E_WARNING | E_PARSE |E_NOTICE);
ini_set ('display_errors', 1);
include ("../account.php");
$db = mysqli_connect ($hostname, $username, $password, $project);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL.";
  mysqli_connect_error();
  exit();
}
$readerID = $_GET['readerID'];
$returnDoc = $_GET['returnDoc'];
$libID = $_GET['libID'];

$returnQuery = "UPDATE BORROWS SET RDTIME = NOW() WHERE BORNUMBER = '$returnDoc' AND LIBID = '$libID'";
($t = mysqli_query($db, $returnQuery))  or  die (mysqli_error($db));
echo "Successfully returned.";
?>